/**************************************************/
/* tp_env.h                                       */
/* Header for environment of TP                   */
/*                                                */
/**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include "blaslapack_headers.h"
